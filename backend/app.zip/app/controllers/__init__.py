from .controller_admin import bp_admin
from .controller_auth import bp_auth
from .controller_model import bp_model
from .controller_user import bp_user